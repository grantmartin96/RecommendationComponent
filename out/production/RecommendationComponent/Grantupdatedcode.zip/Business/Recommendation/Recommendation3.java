package Business.Recommendation;

public class Recommendation3 extends Recommendation{
    public Recommendation3() {
        restaurantName = "McDonalds";
        distance = "0.3 miles";
        roundTripTime = "20 minutes";
        currentNumberPeople = "18";

    }
}
