package Business.Recommendation;

import java.util.ArrayList;

public class Recommendation {
    String restaurantName;
    String distance;
    String roundTripTime;
    String currentNumberPeople;

    ArrayList<String> users = new ArrayList<String>();

    void restaurantName() {
        System.out.println("Name of Restaurant: " + restaurantName);
    }
    void distance() {
        System.out.println("Distance:" + distance);
    }
    void roundTripTime() {
        System.out.println("Round Trip Time:" + roundTripTime);
    }
    void currentNumberPeople(){
        System.out.println("Current Number of People:" + currentNumberPeople);
    }

}