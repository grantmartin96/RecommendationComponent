package Business.Recommendation;

public class Recommendation1 extends Recommendation{
    public Recommendation1() {
        restaurantName = "Five Guys";
        distance = "1.2 miles";
        roundTripTime = "35 minutes";
        currentNumberPeople = "21";
    }
}