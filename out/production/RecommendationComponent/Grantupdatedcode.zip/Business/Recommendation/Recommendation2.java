package Business.Recommendation;

public class Recommendation2 extends Recommendation{
    public Recommendation2() {
        restaurantName = "KFC";
        distance = "1.1 miles";
        roundTripTime = "15 minutes";
        currentNumberPeople = "8";

    }
}
