package Business.Preference;

class TestDecoratorPattern {

    public static void main(String[] args) {

        Preference preference = new Preference1();

        preference = new AddingPreference(preference);

        System.out.println("Type of Restaurant: "+preference.gettypeRestaurant());
        System.out.println("Chosen Cuisine: "+preference.getcuisine());
        System.out.println("Type of Food: "+preference.gettypeFood());
        System.out.println("Dietary Restrictions: "+preference.getdietaryRestrictions());
        System.out.println("Allergy Information: "+preference.getallergyInformation());

        preference = new AddingPreference1(preference);

        System.out.println("Type of Restaurant: "+preference.gettypeRestaurant());
        System.out.println("Chosen Cuisine: "+preference.getcuisine());
        System.out.println("Type of Food: "+preference.gettypeFood());
        System.out.println("Dietary Restrictions: "+preference.getdietaryRestrictions());
        System.out.println("Allergy Information: "+preference.getallergyInformation());

    }
}
