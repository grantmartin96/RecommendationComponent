package Business.Preference;

public interface Preference {

    public String gettypeRestaurant();
    public String getcuisine();
    public String gettypeFood();
    public String getdietaryRestrictions();
    public String getallergyInformation ();

}
