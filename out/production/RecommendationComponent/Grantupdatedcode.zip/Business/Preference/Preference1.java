package Business.Preference;

public class Preference1 implements Preference {

    @Override
    public String gettypeRestaurant() {
        return "Takeaway";
    }

    @Override
    public String getcuisine() {
        return "Chinese";
    }

    @Override
    public String gettypeFood() {
        return "Rice";
    }

    @Override
    public String getdietaryRestrictions() {
        return "None";
    }
    @Override
    public String getallergyInformation() {
        return "Nuts";
    }
}
