package MockTesting;

import Business.User;

public interface NativeMapInterface {

    User getUserLocation(String userLocation);

}